Telegram bot developed with python-aiogram for crocodile word game
